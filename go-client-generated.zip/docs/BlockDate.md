# BlockDate

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Date** | **string** | The date of the block | [default to null]
**Block** | **float64** | The blocknumber | [default to null]
**Timestamp** | **float64** | The timestamp of the block | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

