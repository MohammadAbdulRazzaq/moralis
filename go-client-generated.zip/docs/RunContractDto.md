# RunContractDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Abi** | [***interface{}**](interface{}.md) | The contract abi | [default to null]
**Params** | [***interface{}**](interface{}.md) | The params for the given function | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

