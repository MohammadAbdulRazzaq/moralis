# NativeBalance

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Balance** | **string** | The balance | [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

